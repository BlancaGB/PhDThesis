%%  Script to calculate the number of topics based on Abstracts
%   April 2021. Blanca González Bermúdez
%   Version 1.0 ; Matlab version R2018b M
    clear all; close all
%%  1st. Import Abstracts from Excel File Column
%   Import in Matlab the whole Excel Table from Bibliobetrix 
%   in the format 'table'. Rename the variable as 'table'

%%  2nd. Tokenization of Abstracts
%   A tokenized document is a document represented as a collection 
%   of words (also known as tokens) which is used for text analysis.
   
    documents=tokenizedDocument(table.AB);
    rawBag = bagOfWords(documents);
    
    cleanedDocument = erasePunctuation(documents);
    cleanedDocument = addPartOfSpeechDetails(cleanedDocument);
    cleanedDocument = normalizeWords(cleanedDocument,'Style','lemma');
    cleanedDocument = removeShortWords(cleanedDocument,3);
    cleanedDocument = removeLongWords(cleanedDocument,15);
   
%   These words will be removed from the tokenized abstract aray
    words = ["this" "↵" "with" "which" "from" "that" "have" "cell"...
    "Cell" "cells" "Cells" "into" "they" "might" "many" ...
    "clear" "must" "many" "were" "only" "will" "between" ... 
    "other" "2000" "2001" "2002" "2003" "2004" "2005" "2006"...
    "2007" "2008" "2009" "2010" "within" "example" "when" "where"...
    "shown" "also" "both" "then" "However" "than" "after" "well"...
    "more" "such" "been" "using" "same" "through" "number"... 
    "over" "there" "three" "2018" "high" "same" "observed" "These"...
    "each" "used" "Biol" "during" "these" "their" "This" "first"...
    "different" "could" "described" "Figure" "Biophys" " preprint"...
    "Preprint" "showed" "under" "show" "significantly" "here" "while"];
    cleanedDocument = removeWords(cleanedDocument,words);
    cleanedDocument = lower(cleanedDocument);
    cleanedBag = bagOfWords(cleanedDocument);
    cleanedBag = removeEmptyDocuments(cleanedBag);

%% 3rd. Representation of most frequent wordclouds within abstracts
    wordcloud(cleanedBag);
    title("Cleaned Data")
    
%% 4th. Representation of underlying topics withing abstracts: LDA model

%A Latent Dirichlet Allocation (LDA) model is a topic model which
%discovers underlying topics in a collection of documents.
%Topics, characterized by distributions of words, correspond
%to groups of commonly co-occurring words. LDA is an unsupervised
%topic model which means that it does not require labeled data. 

    numTopics = 6;
    mdl = fitlda(cleanedBag,numTopics,'Verbose',0);
    figure
    set(gcf,'color','w');
    set(gcf, 'Position', [100 400 600 900]);
    for topicIdx = 1:6
        subplot(3,2,topicIdx)
        wordcloud(mdl,topicIdx);
        title("Topic " + topicIdx)
    end

%%  5th. Save figure with the wordclouds of topics 
saveas(gcf,'Topic1_6Topics.png')

