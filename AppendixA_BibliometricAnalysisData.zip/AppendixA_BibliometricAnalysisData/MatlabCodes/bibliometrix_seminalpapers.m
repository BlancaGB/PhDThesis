%%  Script to calculate the nnumber of cited references and 5-year Deviation 

%   April 2021. Blanca González Bermúdez
%   Version 1.0 ; Matlab version R2018b M
    clear all; close all
%%  1st. Import Abstracts from Excel File Column
%   Load column data with Cited References from Excel Table of
%   Bibliometrix; select 'str' format. Rename variable as 'CRdata'

%%  2nd. Run the script 
    ex2=CRdata;
    strAUPY=strings(5e5,2);
    count=1;
    for i = 1:length(ex2)
     out = regexp(ex2, ';', 'split');
        a=cellstr(out{i})';
        out2 = regexp(a, ',', 'split');
        for j = 1:length(out2)
            line=out2{j};
            if length(line)>3
                AUPW=strcat(line{1},line{2});
                PY=line{2};
                AU=strrep(AUPW,' ','');
                PY=strrep(PY,' ','');
                strAUPY(count,1)=AU;
                strAUPY(count,2)=PY;
                count=count+1;
            end
        end      
    end 

    PYvector=str2double(strAUPY(:,2));
    PYvectorOK = PYvector(~isnan(PYvector));
    [valY idY] = unique(PYvectorOK);
    citesPerYear=zeros(length(valY),1);
    for i = 1 : length(valY)
        [idsum log]=find(PYvector==valY(i));
        citesPerYear(i,1)=length(idsum);
    end 

    meadianFiveYear=zeros(length(citesPerYear),1);

    for i = 3:length(citesPerYear)-2
        fiveyearcitesVec=citesPerYear(i-2:i+2);
        meadianFiveYear(i,1)=median(fiveyearcitesVec);
    end

    absdev=zeros(length(citesPerYear),1);
    for i = 3:length(citesPerYear)-2
        absdev(i,1)=((citesPerYear(i,1)-meadianFiveYear(i,1)));
    end 

    indices = find(abs(PYvectorOK)<1850);
    PYvectorOK(indices) = [];

%%  3rd. Representation of Annual distributions of cited references in 
%   publications on research on a given topic 
    figure
    set(gca,'FontSize',14);
    set(gcf,'color','w');
    yyaxis left
    h = histogram(PYvectorOK,length(valY),'Facecolor',[0.5 0.5 0.5],'EdgeColor',[255 255 255]/255)
    [values, edges] = histcounts(PYvectorOK);
    centers = (edges(1:end-1)+edges(2:end))/2;
    %plot(centers, values, 'k-','LineWidth',2)
    ylabel('Number of cited references')
    set(gca, 'XColor','k', 'YColor','k')
    yyaxis right
    [pks,locs] = findpeaks(absdev,'MinPeakProminence',20,'Annotate','extents');
    p = plot(valY,absdev,'-','Color',[242 101 50]/255);
    hold on 
    plot(valY(locs),absdev(locs),'o','MarkerSize',6)
    hold on 
    text(valY(locs)-12,pks,num2str(valY(locs)),'Fontsize',10,'Color',[242 101 50]/255,'FontWeight','bold')
    xlim([1850 2030]);
    ylabel('Deviation from 5-years centered median')
    xlim([1850 2030]);
    p.LineWidth = 1.5;
    xlabel('Year of Publication')


%%  4th. Representation of seminal papers in publications on research 
%   on a given topic 

    [PYord,I] = sort(PYvector);
    AUord =strAUPY(I,1);
    seminalYears=valY(locs); 
    dataSeminalYears=strings(200,2*length(seminalYears));
    filename = 'Topic5_SeminalYearsAuthors.xlsx';

    for i = 1:length(seminalYears)
        [o u] = find(PYord==seminalYears(i));
        AUordpar=AUord(o);
        documents = tokenizedDocument(AUordpar);
        words = [num2str(seminalYears(i)) "." "a" "A"];
        cleanedDocument = removeWords(documents,words);
        Bag = bagOfWords(cleanedDocument);
        figure(1)
        set(gcf, 'Position', [100 400 1300 500]);
        subplot(1,2,1)
        ww= wordcloud(Bag);
        wcData=ww.WordData;
        wcSize=ww.SizeData;
        title({'Cited articles in the WOS dataset: "hyphal" AND "growth" AND "tip",',...
        strcat('with Publication year = ', num2str(seminalYears(i)))})

        subplot(1,2,2)
        if length(wcSize)>25
            plot(1:25,wcSize(1:25)*(100/sum(wcSize)),'o-','Color',[242 101 50]/255,...
            'MarkerFaceColor',[242 101 50]/255);
            hold on 
            txt=text(1.2:1:25+0.2,wcSize(1:25)*(100/sum(wcSize)),wcData(1:25),...
            'Fontsize',10,'Color',[242 101 50]/255,'FontWeight','bold');
            ylim([0 100]);
            xlim([0 35]);
        else
            plot(1:length(wcSize),wcSize*(100/sum(wcSize)),'o-','Color',[242 101 50]/255,...
            'MarkerFaceColor',[242 101 50]/255);    
            hold on 
            txt=text(1.2:1:(length(wcSize)+0.2),wcSize*(100/sum(wcSize)),wcData,...
            'Fontsize',10,'Color',[242 101 50]/255,'FontWeight','bold');
            ylim([0 100]);
            xlim([0 35]);
        end
        set(txt,'Rotation',45)
        xlabel(strcat('Most cited articles published in ',num2str(seminalYears(i))))
        ylabel(strcat('Concentration of cites in ', num2str(seminalYears(i)), ' (%)'))
        set(gca,'FontSize',16);
        set(gcf,'color','w');
        hold off
        saveas(gcf,strcat('Topic5_PY_',num2str(seminalYears(i)),'.png'))
        if i == 1
            dataSeminalYears(1:length(wcData),i)=wcData;
            dataSeminalYears(1:length(wcSize),i+1)=split(num2str(wcSize*(100/sum(wcSize))'));
        else 
            dataSeminalYears(1:length(wcData),2*i-1)=wcData;
            dataSeminalYears(1:length(wcSize),2*i)=split(num2str(wcSize*(100/sum(wcSize))'));
        end
        clear wcData wcSize
    end 
%%  5th. Save seminal papers information in Excel File 
    dataSeminalYearsCell = cellstr(dataSeminalYears);
    writetable(cell2table(dataSeminalYearsCell),filename,'FileType','spreadsheet')

