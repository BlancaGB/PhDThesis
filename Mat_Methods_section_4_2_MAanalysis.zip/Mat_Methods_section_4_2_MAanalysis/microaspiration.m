%% Section 1: crop videos and info of the tests  

%Este programa lee de los archivos de texto registrados por el ordenador de
%ensayos. Para cada experimento se extrae el tiempo, el nombre y la presion 
%(gracias al desplazamiento del deposito de agua) en cada una de las imagenes.
% Se guarda en 'rutaVideos' esta informacion. Ademas, genera un video con la
%informacion mencionada que se puede recortar para encuadrar a la celula.

clc
clear all
close all

% Inputs:

% Date of the test 'date', type of T cell 'type', number of mouse
% 'numMouse', total number of tests 'tot'

Round='1';
date='2018_07_16';
type='CD4_Memory';
numMouse='5';
tot=22;

rutaTiempos=strcat('E:\CTB_Backup_Microscope\mecTage\PDMS_MultiWells\Lymphocytes_',date,'_Mouse',numMouse);
rutaVideos=strcat('E:\CTB_Backup_Microscope\mecTage\PDMS_MultiWells\Analysis\Round',Round,'\Lymphocytes_',date,'_Mouse',numMouse,'\Analysis_',type,'\Videos');
rutaFiles=strcat('E:\CTB_Backup_Microscope\mecTage\PDMS_MultiWells\Analysis\Round',Round,'\Lymphocytes_',date,'_Mouse',numMouse,'\Analysis_',type,'\Names_Pressures_Times');
rutaFotosCarpetas=strcat(rutaTiempos,'\',type);


for j= 1:tot
    %---------------------------------------------------------------
    NameTest=strcat('Mouse',numMouse,'_',type,'_',date,'_Test',num2str(j));
    rutaFotos=strcat(rutaTiempos,'/',type,'/',NameTest,'/');
    %----------------Extraccion de tiempos--------------------------
    
    cd (rutaTiempos)
    Dir_0=dir('*.txt');
    for u=1:length(Dir_0)
        aux=Dir_0(u).name;
        registro=aux(1:end);
        cd (rutaTiempos)
        fileID = fopen(registro);
        if fileID == -1
            error('Cannot open file');
        end
        formatSpec = '%s %f %f %f %s';
        Data = textscan(fileID,formatSpec,'HeaderLines',2,'Delimiter','\t');
        fclose(fileID);
        TiempoColumna=Data{1,2};
        Desp=Data{1,3};
        Reference=Data{1,5};
        
        % Extraccion del array con todos los nombres de las fotos del
        % registro, en donde buscaremos luego las del ensayo.
        count2=1;
        Reference_v=cell(10000,1);
        for i=1:length(Reference)
            a=Reference{i};
            newa=a(2:(length(a)-5)); % para quitar la \_ y el .jpeg.
            Reference_v{i}=newa;
            count2=count2+1;
        end
        ReferenceF=Reference_v(1:count2-1,1);
        
        % Deteccion de la primera foto y de la ultima foto del ensay.
        cd (rutaFotos)
        Dir_1=dir('*.jpeg');
        count1=1;
        Name_v=cell(1000,1);
        for j2=1: length(Dir_1)/2
            name=Dir_1(j2).name;
            newname=name(1:(length(name)-5)); % para quitar la _ y el .jpeg.
            Name_v{j2}=newname;
            count1=count1+1;
        end
        Names=Name_v(1:count1-1,1);
        aux=Names{1};
        aux2=Names{end};
        Foto_0=aux(1:end);
        Foto_F=aux2(1:end);
        
        % Obtencion del numero de la foto inicial y de la foto final.
        for k=1:length(ReferenceF)
            Foto=ReferenceF{k};
            tf = strcmp(Foto,Foto_0); %funcion para comparar strings
            tf2 = strcmp(Foto,Foto_F);
            if tf ==1
                num_foto0=k;
            end
            if tf2 ==1
                num_fotoF=k;
            end
            
        end
        
        % Extraccion del tiempo, presion y nombre del ensayo concreto.
        if exist('num_foto0','var')
            disp_ensayo=Desp(num_foto0:num_fotoF);
            time_raw=TiempoColumna(num_foto0:num_fotoF);
            Time=time_raw-time_raw(1)*ones(size(time_raw));
            Pressures=-9.8*disp_ensayo;
            break
        end
    end
    
    %----------------Creacion de videos--------------------------

    cd(rutaVideos)
    
    vidObj=VideoWriter(strcat(NameTest,'.avi'));
    vidObj.Quality=100;
    vidObj.FrameRate=10;
    open(vidObj);
    
    cd(rutaFotos)
    Dir_img=dir('*.jpeg');
    %Dir_img=Dir_img(2:end); % solo para el dia 1 , exto 6 y dia 2, exto 5
    aux=Dir_img(1).name;
    [A,map]=imread(strcat(rutaFotos,aux(1:end)));
    [X,Y,ImgCrop,rect]=imcrop(A);
    close
    for i= 1: length(Dir_img)/2
        aux=Dir_img(i).name;
        [A,map]=imread(strcat(rutaFotos,aux(1:end)));
        A=imcrop(A,rect);
        string=strcat(Names{i},'  Photo:  ',num2str(i), '/',...
            num2str(length(Dir_img)/2),'   t= ',num2str(Time(i)),' s',...
            '     DP= ', num2str(Pressures(i)), '  Pa');
        
        % Version Matlab pre2017
%         htxtins = vision.TextInserter(string);
%         htxtins.Color = [255, 255, 255];
%         htxtins.FontSize = 15;
%         S=size(A);
%         htxtins.Location = [10 S(1)-50];
%         J = step(htxtins, A);
%        Version Matlab 2017
          S=size(A);
          Location = [10 S(1)-50];
          J = insertText(A,Location,string,'FontSize',15,'TextColor','white','BoxOpacity',0);
          imshow(J)
          I= getframe(gca);
          size(I.cdata);
          writeVideo(vidObj,I);
    end
    close
    close(vidObj);
    
    %----------------Datos que se guardan--------------------------
    cd(rutaFiles)
    title=strcat(rutaFiles,'\',NameTest,'.mat');
    save(title','Time','Names','Pressures');
    clear num_foto0 num_fotoF
end


%% Section 2: 
%Este programa abre los videos de los experimentos generados anteriormente
%y permite indicar para la primera imagen de ellos el diametro de la pipeta
% y el diametro de la celula. Se guarda en 'rutaVideos' los radios medidos
%y el parametro Rc/Rp.
clc; close all
clear all 

Round='1';
date='2018_07_16';
numMouse='5';	
type='CD4_Memory';
%type='CD4_Naive';
%type='CD8_Memory';
%type='CD8_Naive';

%-------------------------------------------------------------------
rutaVideos=strcat('E:\CTB_Backup_Microscope\mecTage\PDMS_MultiWells\Analysis\Round',Round,'\Lymphocytes_',date,'_Mouse',numMouse,'\Analysis_',type,'\Videos');
rutaRcRp=strcat('E:\CTB_Backup_Microscope\mecTage\PDMS_MultiWells\Analysis\Round',Round,'\Lymphocytes_',date,'_Mouse',numMouse,'\Analysis_',type);

%-------------------------------------------------------------------
cd(rutaVideos)
tot=length(dir('*.avi'));
RcRpv=zeros(tot,1);
Rpv=zeros(size(RcRpv));
Rcv=zeros(size(RcRpv));
%-------------------------------------------------------------------
for j=1:tot
    %---------------------------------------------------------------
    NameTest=strcat('Mouse',numMouse,'_',type,'_',date,'_Test',num2str(j));
    %---------------------------------------------------------------
    ObjImages = VideoReader(strcat(NameTest,'.avi'));
    vidWidth = ObjImages.Width;
    vidHeight = ObjImages.Height;
    numFrames=ObjImages.NumberOfFrames;
    tensImages= zeros(vidHeight,vidWidth,numFrames);
    ObjImages = VideoReader(strcat(NameTest,'.avi'));
    mov = struct('cdata',zeros(vidHeight,vidWidth,3,'uint8'),...
        'colormap',[]);
    k = 1;
    while hasFrame(ObjImages)
        mov(k).cdata = readFrame(ObjImages);
        A=mov(k).cdata;
        Ag=A(:,:,2); %solo Greens
        Agd=im2double(Ag);
        tensImages(:,:,k)=Agd;
        k = k+1;
    end
    %----------------------------------------------------------------
    fig=figure('units','normalized','outerposition',[0 0 1 1])
    imshow(tensImages(:,:,1))
    truesize(fig,[800 1000])
    zoom(2)
    h1 = imline
    api1 = iptgetapi(h1)
    pos1 = api1.getPosition() %[X1 Y1; X2 Y2]. %2Rp
    h2 = imline
    api2 = iptgetapi(h2)
    pos2 = api2.getPosition() %[X1 Y1; X2 Y2]. %2Rc
    close
    Dp=sqrt((pos1(1,1)-pos1(2,1))^2+(pos1(1,2)-pos1(2,2))^2);
    Rp=Dp/2;
    Dc=sqrt((pos2(1,1)-pos2(2,1))^2+(pos2(1,2)-pos2(2,2))^2);
    RcRp=Dc/Dp;
    RcRpv(j,1) =  RcRp;
    Rpv(j,1)=Rp;
    Rcv(j,1)=Dc/2;
    
end
%---------------------Datos que se guardan--------------------------
cd(rutaRcRp)
NameRcRp=strcat('Mouse',numMouse,'_',type,'_',date,'_RcRp','.mat');
save(NameRcRp,'RcRpv','Rpv','Rcv');


%% Section 3: 

% Este programa abre los videos de los experimentos y permite indicar el
% frente de avance de la cï¿½lula Lp en cada una de las imï¿½genes. Se guarda 
% 'rutaText' un tensor 'tensResults', con el tiempo normalizado para 
% cada experimento, Lp/Rp y el ratio Rc/Rp. 
% Atenciï¿½n!!: Se introduce manualmente en un archivo situado en 'rutaText'
% la primera imagen que cumple Lp/Rp=1 (para t=0) y la ï¿½ltima imagen del 
% expto correspondiente a la succiï¿½n total de la cï¿½lula. 

clear all 
clc 
close all 

Round='1';
date= '2018_07_16';
numMouse='5';
type='CD4_Memory';
%type='CD4_Naive';
%type='CD8_Memory';
%type='CD8_Naive';
%tot=11;


rutaVideos=strcat('/Volumes/BGB/CTB_Backup_Microscope/mecTage/PDMS_MultiWells/Analysis/Round',Round,'/Lymphocytes_',date,'_Mouse',numMouse,'/Analysis_',type,'/Videos');
rutaRcRp=strcat('/Volumes/BGB/CTB_Backup_Microscope/mecTage/PDMS_MultiWells/Analysis/Round',Round,'/Lymphocytes_',date,'_Mouse',numMouse,'/Analysis_',type);
rutaFiles=strcat('/Volumes/BGB/CTB_Backup_Microscope/mecTage/PDMS_MultiWells/Analysis/Round',Round,'/Lymphocytes_',date,'_Mouse',numMouse,'/Analysis_',type,'/Names_Pressures_Times');
cd(rutaVideos)
tot=length(dir('*.avi'));

numImagAnalysedE=5; 
numImagAnalysedVisc=5; 
numImagAnalysed=numImagAnalysedE+numImagAnalysedVisc;

tensResults=zeros(numImagAnalysed,7,tot);
NameRcRp=strcat('Mouse',numMouse,'_',type,'_',date,'_RcRp','.mat');
NameOrden=strcat('Mouse',numMouse,'_',type,'_',date,'_Order','.mat');
cd(rutaRcRp)
load(NameRcRp)
load(NameOrden)

for j=5% :tot
    
    NameTest=strcat('Mouse',numMouse,'_',type,'_',date,'_Test',num2str(j));
    cd(rutaFiles)
    load(strcat(NameTest,'.mat'))

    posTimeInicial=Orden(j,1);
    posTimeFinal=Orden(j,2);
    
    %fact= round((posTimeFinal-posTimeInicial+1)/(numImagAnalysedE-1));
    fact= floor((posTimeFinal-posTimeInicial)/(numImagAnalysedE-1));
    initialImageVisc=round(2*numImagAnalysedE/3);
    factVisc= floor((posTimeFinal-initialImageVisc*fact)/(numImagAnalysedVisc-1));

    count=0; 
    vectPosicionesTime=zeros(numImagAnalysed,1);

    % elastic modulus
    for k= 1:(posTimeFinal-posTimeInicial+1)
        if fact >1 
            if mod(k, fact) ==1
            count=count+1; 
            vectPosicionesTime(count,1)=k+posTimeInicial-1;
            end
        end 
        if fact==1 && k<=numImagAnalysedE
           vectPosicionesTime(k,1)=posTimeInicial+k-1;
        end   
    end
    
    % viscosity 
    v=initialImageVisc*fact:factVisc:posTimeFinal;
   if factVisc==0 
    vectPosicionesTime(1:end)=1:1:numImagAnalysed;   
   else 
    vectPosicionesTime(numImagAnalysedE+1:end)=v(1:numImagAnalysedVisc);
   end
%     if vectPosicionesTime(end)==0
%         vectPosicionesTime(end) = posTimeFinal;
%     end 
%     if vectPosicionesTime(end-1)==0
%         vectPosicionesTime (end-1) = posTimeFinal-1;
%          vectPosicionesTime (end-2) = posTimeFinal-2;
%     end 
%     

    timeExpto=zeros(numImagAnalysed,1);
    PressExpto=zeros(numImagAnalysed,1);

    for l=1:numImagAnalysed
        timeExpto(l,1)=Time(vectPosicionesTime(l))-...
        Time(vectPosicionesTime(1)) ;
        PressExpto(l,1)=Pressures(vectPosicionesTime(l));
    end

    timeExptoNorm=timeExpto/(timeExpto(end));

    %NameTest='Mouse3_CD4_Memory_2017_05_23_Test1';
    cd(rutaVideos)
    ObjImages = VideoReader(strcat(NameTest,'.avi')); 
    vidWidth = ObjImages.Width;
    vidHeight = ObjImages.Height;
    numFrames=ObjImages.NumberOfFrames;
    tensImages= zeros(vidHeight,vidWidth,numFrames);
    ObjImages = VideoReader(strcat(NameTest,'.avi')); 
    mov = struct('cdata',zeros(vidHeight,vidWidth,3,'uint8'),...
        'colormap',[]);
    k = 1;
    while hasFrame(ObjImages)
        mov(k).cdata = readFrame(ObjImages);
        A=mov(k).cdata;
        Ag=A(:,:,2); %solo Greens
        Agd=im2double(Ag);
        tensImages(:,:,k)=Agd; 
        k = k+1;
    end
   
    Lp=zeros(numImagAnalysed,1);
    LpRp=zeros(numImagAnalysed,1);
    Lp(1,1)= Rpv(j);

    for m= 1:numImagAnalysed
        fig= figure('units','normalized','outerposition',[0 0 1 1])
        imshow(tensImages(:,:,vectPosicionesTime(m)))
        truesize(fig,[800 1000])
        zoom(1.5)
        h1 = imline % d1
        api1 = iptgetapi(h1)
        pos1 = api1.getPosition() %[X1 Y1; X2 Y2].
        h2 = imline  %d2
        api2 = iptgetapi(h2)
        pos2 = api2.getPosition() %[X1 Y1; X2 Y2].
        h3 = imline  %lp
        api3 = iptgetapi(h3)
        pos3 = api3.getPosition()   
        close 
        d1(m,1)=sqrt((pos1(1,1)-pos1(2,1))^2+(pos1(1,2)-pos1(2,2))^2);
        d2(m,1)=sqrt((pos2(1,1)-pos2(2,1))^2+(pos2(1,2)-pos2(2,2))^2);
        Lp(m,1)=sqrt((pos3(1,1)-pos3(2,1))^2+(pos3(1,2)-pos3(2,2))^2);
    end
    LpRp=Lp/Rpv(j); 
    close
    tensResults(:,1,j)=d1;
    tensResults(:,2,j)=d2/cos(20*pi/180);
    tensResults(:,3,j)=LpRp/cos(20*pi/180);
    tensResults(:,4,j)=timeExptoNorm; 
    tensResults(:,5,j)=timeExpto; 
    tensResults(:,6,j)=PressExpto; 
    tensResults(1,7,j)=RcRpv(j); 

end 

NameResults=strcat('Mouse',numMouse,'_',type,'_',date,'_MeasuresLpRp_new2','.mat');
cd (rutaRcRp)
save(NameResults,'tensResults');


%% Step 4

% Programa que importa los resultados 'tensResults', con el tiempo normalizado
%para  cada experimento, Lp/Rp y el ratio Rc/Rp. A continuaciï¿½n clasifican
%los resultados en funciï¿½n de su rango Rc/Rp y se genera un tensor 'TensFinal' con 
%el mï¿½nimo nï¿½mero de experimentos que ha aparecido para un rango Rc/Rp. En
%este caso, he encontrado 12 casos como mï¿½nimo (ver histograma). 

clear all 
clc 

Round='1';
date= '2018_07_16';
numMouse='5';

type='CD4_Memory';
%type='CD4_Naive';
%type='CD8_Memory';
%type='CD8_Naive';
%tot=11;

rutaRcRp=strcat('/Volumes/BGB/CTB_Backup_Microscope/mecTage/PDMS_MultiWells/Analysis/Round',Round,'/Lymphocytes_',date,'_Mouse',numMouse,'/Analysis_',type);
rutaFiles=strcat('/Volumes/BGB/CTB_Backup_Microscope/mecTage/PDMS_MultiWells/Analysis/Round',Round,'/Lymphocytes_',date,'_Mouse',numMouse,'/Analysis_',type,'/Names_Pressures_Times');
cd(rutaRcRp)

NameMeasures=strcat('Mouse',numMouse,'_',type,'_',date,'_MeasuresLpRp_corr2','.mat');
NameOrder=strcat('Mouse',numMouse,'_',type,'_',date,'_Order','.mat');
NameRcRp=strcat('Mouse',numMouse,'_',type,'_',date,'_RcRp','.mat');
load(NameMeasures);
load(NameOrder);
load(NameRcRp);

%CORREGIR LP=x-h

% Elastic Modulus 

beta1= 2.0142;
beta3=2.1187;
DP=tensResults(:,6,:);
DP=reshape(DP,size(tensResults,1),size(tensResults,3));
LpRp=tensResults(:,3,:);
LpRp=reshape(LpRp,size(tensResults,1),size(tensResults,3));
RpR0v=1/tensResults(1,7,:);
RpR0v=reshape(RpR0v,size(tensResults,3),1);
RpR0=ones(size(LpRp));
RP=ones(size(LpRp));
R0=ones(size(LpRp));

for i =1:length(RpR0v)
    for j=1:size(tensResults,1)
    RpR0(j,i)=RpR0v(i);
    RP(j,i)=Rpv(i);
    R0(j,i)=Rcv(i);
    end
end
h= R0.*(1-(1-(RpR0).^2).^0.5);
Cl= 1./(beta1*(1-(RpR0).^beta3));
%E=(3*Cl.*DP)./((LpRp.*RP-h)./RP);
E=(3*Cl.*DP)./(LpRp);
E_limits=zeros(size(E));

for i = 1:size(LpRp,1)
    for j=1:size(LpRp,2)
        if LpRp(i,j) <=0.1 || LpRp(i,j) >=1.55 || Cl(i,j)<0 
           E_limits(i,j)= 0;
        else
           E_limits(i,j)= E(i,j);       
        end
    end
end

nE_mean=sum(E_limits~=0);
nE_mean(nE_mean==0)=NaN;
E_mean_exp=sum(E_limits)./nE_mean;
errorE_mean_exp=std(E_limits)./sqrt(nE_mean);
errorE_mean_exp(find(isnan(errorE_mean_exp)))=[];
errorE_mean_exp(find(isinf(errorE_mean_exp)))=[];
E_mean_exp(find(isnan(E_mean_exp)))=[];
E_mean_exp(find(isinf(E_mean_exp)))=[];
E_mean_pop=mean(E_mean_exp)
errorE=std(E_mean_exp)/sqrt(length(E_mean_exp))


% Viscosity 

D1=tensResults(:,1,:);
D1=reshape(D1,size(tensResults,1),size(tensResults,3));
D2=tensResults(:,2,:);
D2=reshape(D2,size(tensResults,1),size(tensResults,3));
T=tensResults(:,5,:);
T=reshape(T,size(tensResults,1),size(tensResults,3));

V1=0.5*(4/3)*pi.*RP.^3 + pi.*(RP.^2).*(LpRp.*RP-RP);
V2= (pi/6).*(D1.^2).*D2;
Vtot=V1+V2; 
Vin = V1 - (pi/6).*h.*(3.*RP.^2+h.^2);
VinVtot=Vin./Vtot; 
DeltaPspeed=5; % Pa/s
m=6;
Visc=(3*(0.5*DeltaPspeed*T.^2).*RpR0.^3)./(4*m.*(ones(size(RpR0))-RpR0).*VinVtot);
Visc_limits=zeros(size(Visc));


for i = 1:size(VinVtot,1)
    for j=1:size(VinVtot,2)
        if VinVtot(i,j) <=0.2 || VinVtot(i,j) >=0.45
           Visc_limits(i,j)= 0;
        else
           Visc_limits(i,j)= Visc(i,j);       
        end
    end
end


nVisc_mean=sum(Visc_limits~=0);
nVisc_mean(nVisc_mean==0)=NaN;
Visc_mean_exp=sum(Visc_limits)./nVisc_mean;
errorVisc_mean_exp=std(Visc_limits)./sqrt(nVisc_mean);
errorVisc_mean_exp(find(isnan(Visc_mean_exp)))=[];
errorVisc_mean_exp(find(isinf(Visc_mean_exp)))=[];
errorVisc_mean_exp(find(Visc_mean_exp<0))=[];
Visc_mean_exp(find(isnan(Visc_mean_exp)))=[];
Visc_mean_exp(find(Visc_mean_exp<0))=[];
Visc_mean_exp(find(isinf(Visc_mean_exp)))=[];
Visc_mean_pop=mean(Visc_mean_exp)
errorVisc=std(Visc_mean_exp)/sqrt(length(Visc_mean_exp))

% Transit time 
transTime=zeros(1,size(tensResults,3));
for i=1:size(tensResults,3)
    cd(rutaFiles)
    NameTest=strcat('Mouse',numMouse,'_',type,'_',date,'_Test',num2str(i),'.mat');
    load(NameTest)
    transTime(i)= Time(Orden(i,2))-Time(Orden(i,1));
end

transTime_mean=mean(transTime)
errortransTime=std(transTime)/sqrt(length(transTime))


MechanicalResults=zeros(size(tensResults,1),size(tensResults,3),4);
MechanicalResults(:,:,1)=E;
MechanicalResults(:,:,2)=E_limits;
MechanicalResults(:,:,3)=Visc_limits;
MechanicalResults(:,:,4)=Visc_limits;

NameResults=strcat('Mouse',numMouse,'_',type,'_',date,'_MechanicalParameters_corr2','.mat');
cd (rutaRcRp)
save(NameResults,'MechanicalResults','E_mean_exp','E_mean_pop','errorE',...
            'Visc_mean_exp','Visc_mean_pop','errorVisc',...
            'transTime','transTime_mean','errortransTime'); 
        
%%
figure ()
for i = 1:size(tensResults,3)
    plot(tensResults(:,5,i),tensResults(:,3,i),'*-')
    hold on 
end 
hold off

figure()
plot(1:size(E_mean_exp,2),E_mean_exp,'o')

figure()
plot(1:1:size(Visc_mean_exp,2),Visc_mean_exp,'o')

E_mean_pop=mean(E_mean_exp)
errorE=std(E_mean_exp)/sqrt(length(E_mean_exp))
Visc_mean_pop=mean(Visc_mean_exp)
errorVisc=std(Visc_mean_exp)/sqrt(length(Visc_mean_exp))
NameResults=strcat('Mouse',numMouse,'_',type,'_',date,'_MechanicalParameters3','.mat');
cd (rutaRcRp)
save(NameResults,'MechanicalResults','E_mean_exp','E_mean_pop','errorE',...
            'Visc_mean_exp','Visc_mean_pop','errorVisc',...
            'transTime','transTime_mean','errortransTime'); 
        
        %%

% tests=1:1:size(tensResults,3);
% legendCell=cellstr(num2str(tests','test%-d'));

% fig1 = figure ;
% set(fig1, 'Units', 'centimeters') 
% set (fig1,'PaperType','A4')
% set(fig1, 'Position', [0 0 21 29.7])
% 
% % A4_1: LpRp vs t and DP vs t 
% a1=subplot('Position', [0.15 0.55 0.75 0.35]) ;
% for i=1:size(tensResults,3)
%    set(gca,'fontsize',16) 
%    plot(T(:,i),tensResults(:,3,i),'+-')
%    hold on 
%    ylabel('Lp/Rp','Fontsize',18)
%    xlabel('Time (s)','Fontsize',18)
%    legend(legendCell,'Location','northeastoutside','Fontsize',11)
% end
% hold off 
% b1=subplot('Position', [0.15 0.10 0.75 0.35]) ;
% for i=1:size(tensResults,3)
%     set(gca,'fontsize',16)       
%    plot(T(:,i),tensResults(:,6,i),'-o')
%    hold on 
%    xlabel('Time (s)','Fontsize',18)
%    ylabel('\Delta P (Pa)','Fontsize',18)
%    legend(legendCell,'Location','northeastoutside', 'Fontsize',11)
% end
%    hold off 
%    
   % Document's title
% c1=subplot('Position', [0.23 0.93 0.7 0.03]);
% set(c1,'Visible','off');
% str1= ['Mouse', numMouse, '_',type, '_',date];
% t3=text(0.15,0.5,str1);
% set(t3,'Interpreter','none')
% set(t3,'FontSize',14)
% set(t3,'FontWeight','bold')
% 
% set(gcf,'paperunits','centimeters')
% set(gcf,'papertype','a4')
% set(gcf,'paperposition',[0,0,21,29.7])
% nameA4_1=strcat('Mouse',numMouse,'_',type,'_',date,'_1');
% print(fig1, nameA4_1,'-dpdf')
% 
% % A4_2: E vs Lp/Rp and transit time vs Rc/Rp
% fig2 = figure ;
% set(fig2, 'Units', 'centimeters') 
% set (fig2,'PaperType','A4')
% set(fig2, 'Position', [0 0 21 29.7])
% 
% % E vs time
% a2=subplot('Position', [0.15 0.55 0.75 0.35]) ;
% for i=1:size(tensResults,3)
%     set(gca,'fontsize',16)       
%  %  stem(T(:,i),E_limits(:,i),'-o')
%     stem(LpRp(:,i),E_limits(:,i),'-o')
% 
%    hold on 
%    xlabel('Lp/Rp','Fontsize',18)
%    ylabel('Elastic modulus E (Pa)','Fontsize',18)
%    legend(legendCell,'Location','northeastoutside', 'Fontsize',11)
% end
%    hold off 
%    
% b2=subplot('Position', [0.15 0.10 0.75 0.35]) ;
% set(gca,'fontsize',16)       
% %   stem(1:1:size(tensResults,3),transTime,'o')
%    stem(RcRpv,transTime,'o')
%    hold on 
%    xlabel('Rc/Rp','Fontsize',18)
%    ylabel('Transit time (s)','Fontsize',18)
%    
%    % Document's title
% c2=subplot('Position', [0.23 0.93 0.7 0.03]);
% set(c2,'Visible','off');
% str1= ['Mouse', numMouse, '_',type, '_',date];
% t3=text(0.15,0.5,str1);
% set(t3,'Interpreter','none')
% set(t3,'FontSize',14)
% set(t3,'FontWeight','bold') 
% 
% %str1= ['Elastic modulus E = ', num2str(round(E_mean_pop)),'\pm',num2str(round(errorE)) ,' Pa '];
% %t1=text(0.01,-29,str1);
% 
% set(gcf,'paperunits','centimeters')
% set(gcf,'papertype','a4')
% set(gcf,'paperposition',[0,0,21,29.7])
% nameA4_2=strcat('Mouse',numMouse,'_',type,'_',date,'_2');
% print(fig2, nameA4_2,'-dpdf') 
% 
% 
% 
% fig3 = figure ;
% set(fig3, 'Units', 'centimeters') 
% set (fig3,'PaperType','A4')
% set(fig3, 'Position', [0 0 21 29.7])
% 
% % E vs time
% a3=subplot('Position', [0.15 0.55 0.75 0.35]) ;
% for i=1:size(tensResults,3)
%     set(gca,'fontsize',16)       
%    stem(T(:,i),Visc_limits(:,i),'-o')
%    hold on 
%    xlabel('Time (s)','Fontsize',18)
%    ylabel('Viscosity \eta (Pa s)','Fontsize',18)
%    legend(legendCell,'Location','northeastoutside', 'Fontsize',11)
% end
%    hold off 
% b3=subplot('Position', [0.15 0.10 0.75 0.35]) ;
% for i=1:size(tensResults,3)
%     set(gca,'fontsize',16)       
%    stem(VinVtot(:,i),Visc_limits(:,i),'-o')
%    hold on 
%    xlabel('Vin/Vtot','Fontsize',18)
%    ylabel('Viscosity \eta (Pa s)','Fontsize',18)
%    legend(legendCell,'Location','northeastoutside', 'Fontsize',11)
% end
%    hold off 
%    % Document's title
% c3=subplot('Position', [0.23 0.93 0.7 0.03]);
% set(c3,'Visible','off');
% str1= ['Mouse', numMouse, '_',type, '_',date];
% t3=text(0.15,0.5,str1);
% set(t3,'Interpreter','none')
% set(t3,'FontSize',14)
% set(t3,'FontWeight','bold')
%  
% set(gcf,'paperunits','centimeters')
% set(gcf,'papertype','a4')
% set(gcf,'paperposition',[0,0,21,29.7])
% nameA4_3=strcat('Mouse',numMouse,'_',type,'_',date,'_3');
% print(fig3, nameA4_3,'-dpdf')

%str2= ['Viscosity \eta = ', '\pm',num2str(round(errorVisc)) ' Pa\cdots.'];
%t2= text(0.01,-29,str2);

% Saving the A4 figures to pdf 